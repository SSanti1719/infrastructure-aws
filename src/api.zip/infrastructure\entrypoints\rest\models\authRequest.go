package models

type AuthRequest struct {
	Token string `json:"token"`
}
