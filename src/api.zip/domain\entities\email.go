package entities

type Email struct {
	MessageId string
	Date      string
	From      string
	To        string
	Subject   string
	Content   string
}
