package models

type Term struct {
	Term string `json:"term"`
}
