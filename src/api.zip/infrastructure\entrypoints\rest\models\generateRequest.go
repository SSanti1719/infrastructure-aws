package models

type GenerateRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}
