package entities

type Emails struct {
	Length int
	Data   []Email
}
